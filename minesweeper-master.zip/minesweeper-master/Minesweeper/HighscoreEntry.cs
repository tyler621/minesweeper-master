﻿

namespace Minesweeper
{
    public struct HighscoreEntry
    {
        public string Nickname { get; set; }
        public int Time { get; set; }
        public string BoardSize { get; set; }
    }
}